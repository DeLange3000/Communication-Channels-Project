function [x, y] = drawLines()
% creates geometry of Vismarkt

x = [-20 40 0 40 40 40 -20 40 40 40 40 40 40 40; 60 60 0 40 60 60 0 40 60 60 40 60 60 40]; %first point ; second point
y = [0 10 10 10 70 80 10 80 180 190 190 270 280 280; 0 10 320 70 70 80 10 180 180 190 270 270 280 320];

end